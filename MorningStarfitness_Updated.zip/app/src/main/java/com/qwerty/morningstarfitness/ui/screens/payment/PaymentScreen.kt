package com.qwerty.morningstarfitness.ui.screens.payment

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qwerty.morningstarfitness.models.MembershipPlanModel
import com.qwerty.morningstarfitness.ui.components.BrandMark
import com.qwerty.morningstarfitness.ui.components.GhostButton
import com.qwerty.morningstarfitness.ui.components.Heading
import com.qwerty.morningstarfitness.ui.components.PrimaryButton
import com.qwerty.morningstarfitness.ui.components.SectionLabel
import com.qwerty.morningstarfitness.ui.components.SelectableOptionRow
import com.qwerty.morningstarfitness.ui.theme.PulseColors

private data class PaymentOption(val id: String, val label: String)

private val paymentOptions = listOf(
    PaymentOption("mpesa", "M-Pesa"),
    PaymentOption("mastercard", "Mastercard"),
    PaymentOption("paypal", "PayPal"),
)

@Composable
fun PaymentScreen(
    plan: MembershipPlanModel?,
    paymentMethod: String,
    onMethodChange: (String) -> Unit,
    onBack: () -> Unit,
    onConfirm: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PulseColors.Background)
            .padding(20.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 420.dp)
                .background(PulseColors.Surface, RoundedCornerShape(20.dp))
                .padding(24.dp)
        ) {
            BrandMark()
            Heading("Pay for membership")

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Complete this payment to activate your account.",
                color = PulseColors.TextMuted,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PulseColors.SurfaceAlt, RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${plan?.label ?: "No plan selected"} plan",
                    color = PulseColors.TextPrimary,
                    fontSize = 14.sp
                )
                Text(
                    text = plan?.let { "KSh ${it.priceKsh}" } ?: "—",
                    color = PulseColors.Accent,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp
                )
            }

            SectionLabel("Payment method")

            paymentOptions.forEach { option ->
                SelectableOptionRow(
                    label = option.label,
                    selected = paymentMethod == option.id,
                    onClick = { onMethodChange(option.id) }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                GhostButton(
                    text = "Back",
                    onClick = onBack,
                    modifier = Modifier.weight(1f)
                )
                PrimaryButton(
                    text = "Confirm payment",
                    onClick = onConfirm,
                    enabled = plan != null,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
