package com.qwerty.morningstarfitness.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qwerty.morningstarfitness.models.MembershipPlanModel
import com.qwerty.morningstarfitness.ui.components.BrandMark
import com.qwerty.morningstarfitness.ui.components.GhostButton
import com.qwerty.morningstarfitness.ui.components.Heading
import com.qwerty.morningstarfitness.ui.components.QrCodeDisplay
import com.qwerty.morningstarfitness.ui.components.SectionLabel
import com.qwerty.morningstarfitness.ui.theme.PulseColors

@Composable
fun HomeScreen(
    firstName: String,
    plan: MembershipPlanModel?,
    qrCodeValue: String,
    onLogout: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PulseColors.Background)
            .padding(20.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 420.dp)
                .verticalScroll(rememberScrollState())
                .background(PulseColors.Surface, RoundedCornerShape(20.dp))
                .padding(24.dp)
        ) {
            BrandMark()
            Heading("Welcome, $firstName!")

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Here's your membership dashboard.",
                color = PulseColors.TextMuted,
                fontSize = 14.sp
            )

            SectionLabel("Membership plan")

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PulseColors.SurfaceAlt, RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = plan?.label ?: "No active plan",
                        color = PulseColors.TextPrimary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                    Text(
                        text = plan?.let { "${it.durationMonths} month(s) remaining" } ?: "Register to get started",
                        color = PulseColors.TextMuted,
                        fontSize = 12.sp
                    )
                }
                Text(
                    text = plan?.let { "KSh ${it.priceKsh}" } ?: "—",
                    color = PulseColors.Accent,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp
                )
            }

            SectionLabel("My QR code")

            Text(
                text = "Scan this at the front desk to check in.",
                color = PulseColors.TextMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                QrCodeDisplay(content = qrCodeValue, sizeDp = 200.dp)
            }

            SectionLabel("Quick actions")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionTile(
                    icon = "\uD83D\uDCDD",
                    label = "Log Work",
                    modifier = Modifier.weight(1f)
                )
                QuickActionTile(
                    icon = "\uD83C\uDFC6",
                    label = "Stats",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            GhostButton(
                text = "Log out",
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun QuickActionTile(
    icon: String,
    label: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(PulseColors.SurfaceAlt, RoundedCornerShape(12.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = icon, fontSize = 24.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            color = PulseColors.TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center
        )
    }
}
