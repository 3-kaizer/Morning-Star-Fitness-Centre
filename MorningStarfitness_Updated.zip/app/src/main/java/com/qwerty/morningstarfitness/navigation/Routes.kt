package com.qwerty.morningstarfitness.navigation

const val ROUTE_REGISTRATION = "registration"
const val ROUTE_PLAN = "plan"
const val ROUTE_PAYMENT = "payment"
const val ROUTE_SUCCESS = "success"
const val ROUTE_HOME = "home"
