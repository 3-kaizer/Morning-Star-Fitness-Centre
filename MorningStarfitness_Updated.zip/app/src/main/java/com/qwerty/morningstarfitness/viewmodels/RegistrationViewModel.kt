package com.qwerty.morningstarfitness.viewmodels

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.qwerty.morningstarfitness.models.MembershipPlanModel
import com.qwerty.morningstarfitness.ui.screens.registration.MemberFormState
import java.util.UUID

class RegistrationViewModel : ViewModel() {

    var memberForm by mutableStateOf<MemberFormState?>(null)
        private set

    var selectedPlan by mutableStateOf<MembershipPlanModel?>(null)
        private set

    var paymentMethod by mutableStateOf("mpesa")
        private set

    var isProcessingPayment by mutableStateOf(false)
        private set

    var paymentStatus by mutableStateOf("pending")
        private set

    var qrCodeValue by mutableStateOf<String?>(null)
        private set

    fun updateMemberForm(form: MemberFormState) {
        memberForm = form
    }

    fun updateSelectedPlan(plan: MembershipPlanModel) {
        selectedPlan = plan
    }

    fun updatePaymentMethod(method: String) {
        paymentMethod = method
    }

    fun processPayment(): Boolean {
        val validPlan = selectedPlan ?: return false
        val validMember = memberForm ?: return false

        if (validMember.fullName.isBlank() || validPlan.priceKsh <= 0) {
            return false
        }

        paymentStatus = "paid"
        generateQrCode()
        return true
    }

    fun resetRegistrationState() {
        memberForm = null
        selectedPlan = null
        paymentMethod = "mpesa"
        paymentStatus = "pending"
        qrCodeValue = null
    }

    fun generateQrCode(): String {
        val value = "MSF-${UUID.randomUUID()}"
        qrCodeValue = value
        return value
    }
}
