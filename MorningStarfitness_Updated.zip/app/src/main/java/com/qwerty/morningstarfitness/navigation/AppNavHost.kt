package com.qwerty.morningstarfitness.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.qwerty.morningstarfitness.ui.screens.home.HomeScreen
import com.qwerty.morningstarfitness.ui.screens.payment.PaymentScreen
import com.qwerty.morningstarfitness.ui.screens.plan.PlanScreen
import com.qwerty.morningstarfitness.ui.screens.registration.RegistrationScreen
import com.qwerty.morningstarfitness.ui.screens.success.SuccessScreen
import com.qwerty.morningstarfitness.viewmodels.RegistrationViewModel

@Composable
fun AppNavHost(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController(),
    startDestination: String = ROUTE_HOME
) {
    val registrationViewModel: RegistrationViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = modifier
    ) {
        composable(ROUTE_REGISTRATION) {
            RegistrationScreen(
                onContinue = { formState ->
                    registrationViewModel.updateMemberForm(formState)
                    navController.navigate(ROUTE_PLAN)
                }
            )
        }

        composable(ROUTE_PLAN) {
            PlanScreen(
                onBack = { navController.popBackStack() },
                onContinue = { plan ->
                    registrationViewModel.updateSelectedPlan(plan)
                    navController.navigate(ROUTE_PAYMENT)
                }
            )
        }

        composable(ROUTE_PAYMENT) {
            PaymentScreen(
                plan = registrationViewModel.selectedPlan,
                paymentMethod = registrationViewModel.paymentMethod,
                onMethodChange = { registrationViewModel.updatePaymentMethod(it) },
                onBack = { navController.popBackStack() },
                onConfirm = {
                    if (registrationViewModel.processPayment()) {
                        navController.navigate(ROUTE_SUCCESS)
                    }
                }
            )
        }

        composable(ROUTE_SUCCESS) {
            val firstName = registrationViewModel.memberForm?.fullName
                ?.split(" ")
                ?.firstOrNull()
                ?.ifBlank { "there" }
                ?: "there"

            SuccessScreen(
                firstName = firstName,
                plan = registrationViewModel.selectedPlan,
                qrCodeValue = registrationViewModel.qrCodeValue ?: "",
                onContinue = {
                    // Clears the back stack so Back from Home doesn't return
                    // to registration/payment/success.
                    navController.navigate(ROUTE_HOME) {
                        popUpTo(ROUTE_REGISTRATION) { inclusive = true }
                    }
                }
            )
        }

        composable(ROUTE_HOME) {
            val firstName = registrationViewModel.memberForm?.fullName
                ?.split(" ")
                ?.firstOrNull()
                ?.ifBlank { "there" }
                ?: "there"

            HomeScreen(
                firstName = firstName,
                plan = registrationViewModel.selectedPlan,
                qrCodeValue = registrationViewModel.qrCodeValue ?: "",
                onLogout = {
                    registrationViewModel.resetRegistrationState()
                    navController.navigate(ROUTE_REGISTRATION) {
                        popUpTo(ROUTE_HOME) { inclusive = true }
                    }
                }
            )
        }
    }
}
